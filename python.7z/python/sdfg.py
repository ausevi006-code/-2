from selenium import webdriver
from selenium.webdriver.common.by import By
import json
import time

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("http://books.toscrape.com")

books = []
for page in range(1, 6):
    print(f"Парсим страницу {page}...")
    articles = driver.find_elements(By.CSS_SELECTOR, "article.product_pod")
    for article in articles:
        title = article.find_element(By.CSS_SELECTOR, "h3 a").get_attribute("title")
        price = article.find_element(By.CSS_SELECTOR, ".price_color").text
        stock = article.find_element(By.CSS_SELECTOR, ".availability").text.strip()

        books.append({
            "title": title,
            "price": price,
            "stock": stock
        })
    
    # Переход на следующую страницу, если не последняя
    if page < 5:
        next_button = driver.find_element(By.CSS_SELECTOR, "li.next a")
        next_button.click()
        time.sleep(1)

# Сохранение в JSON
with open("books.json", "w", encoding="utf-8") as f:
    json.dump(books, f, ensure_ascii=False, indent=4)

# Поиск и открытие книги "Thirst"
thirst_found = False
for book in books:
    if book["title"] == "Thirst":
        thirst_found = True
        break

if thirst_found:
    driver.get("http://books.toscrape.com")
    for page in range(1, 6):
        try:
            thirst_link = driver.find_element(By.XPATH, '//a[@title="Thirst"]')
            thirst_link.click()
            driver.save_screenshot("thirst_book.png")
            break
        except:
            if page < 5:
                driver.find_element(By.CSS_SELECTOR, "li.next a").click()
                time.sleep(1)

driver.quit()